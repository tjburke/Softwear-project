
import java.util.Scanner;
public class Lisa {

    public static void main(String[] args) {
String name = "lisa";//stores string name
int age = 9;//stores int age
double height =133.3;//stores  double height
String height_type ="centimetres";
double weight=27.8;//stores double weight
String weight_type ="kilograms";
		System.out.println(name+" is "+ age+" years old and is "+ height+" "+height_type+" tall.\n"+name+" weighs "+ weight+" "+weight_type );//prompt








        }// end main

  }//end class