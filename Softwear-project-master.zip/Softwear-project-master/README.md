# Softwear-project
To download the files click the green clone/download button then extract the zip file

To run open index with textpad compile and run
