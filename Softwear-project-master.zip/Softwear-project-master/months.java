/**
Name: months

Description: Looks for any month cointaining r

Created by tj burke


*/

import java.util.Scanner;
public class months {

    public static void main(String[] args) {

String[] Months={"January","February","March","April","May","June","July","August","September","October","November","December"};
int i =1;

			for (int i1=0;i1< Months.length;i1++){

				Months[i1] = Months[i1];
			if(Months[i1].contains("r")){ // checks line by line for a string that has r in it

				System.out.println(Months[i1]);

				}
				}



        }// end main

  }//end class